import React, { useState, useRef, useEffect } from 'react';
import { Upload, Settings, Download, AlertCircle, Smartphone, Package, Globe, Image, FileJson, Shield, Edit, Trash } from 'lucide-react';
import toast, { Toaster } from 'react-hot-toast';

interface ConversionForm {
  websiteUrl: string;
  appName: string;
  packageName: string;
  admobAppId?: string;
  admobBannerId?: string;
  admobInterstitialId?: string;
}

interface FileUpload {
  htmlZip?: File | null;
  appIcon?: File | null;
  splashScreen?: File | null;
}

interface ConvertedApp {
  id: string;
  appName: string;
  packageName: string;
  websiteUrl?: string;
  htmlZip?: string;
  appIcon: string;
  splashScreen?: string;
  createdAt: Date;
  lastUpdated: Date;
}

function App() {
  const [form, setForm] = useState<ConversionForm>({
    websiteUrl: '',
    appName: '',
    packageName: '',
    admobAppId: '',
    admobBannerId: '',
    admobInterstitialId: '',
  });

  const [files, setFiles] = useState<FileUpload>({
    htmlZip: null,
    appIcon: null,
    splashScreen: null,
  });

  const [isConverting, setIsConverting] = useState(false);
  const [showAdmobFields, setShowAdmobFields] = useState(false);
  const [conversionType, setConversionType] = useState<'url' | 'zip'>('url');
  const [convertedApps, setConvertedApps] = useState<ConvertedApp[]>([]);
  const [editingApp, setEditingApp] = useState<ConvertedApp | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load existing apps from localStorage
  useEffect(() => {
    const savedApps = localStorage.getItem('convertedApps');
    if (savedApps) {
      setConvertedApps(JSON.parse(savedApps));
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsConverting(true);
    
    try {
      // Validate files
      if (conversionType === 'zip' && !files.htmlZip) {
        throw new Error('Please upload HTML ZIP file');
      }
      if (!files.appIcon) {
        throw new Error('Please upload app icon');
      }

      // Simulate conversion process
      await new Promise(resolve => setTimeout(resolve, 2000));

      const newApp: ConvertedApp = {
        id: editingApp?.id || Date.now().toString(),
        appName: form.appName,
        packageName: form.packageName,
        websiteUrl: conversionType === 'url' ? form.websiteUrl : undefined,
        htmlZip: conversionType === 'zip' ? files.htmlZip?.name : undefined,
        appIcon: URL.createObjectURL(files.appIcon),
        splashScreen: files.splashScreen ? URL.createObjectURL(files.splashScreen) : undefined,
        createdAt: editingApp?.createdAt || new Date(),
        lastUpdated: new Date(),
      };

      if (editingApp) {
        setConvertedApps(prev => 
          prev.map(app => app.id === editingApp.id ? newApp : app)
        );
        toast.success('App updated successfully!');
      } else {
        setConvertedApps(prev => [...prev, newApp]);
        toast.success('APK conversion completed!');
      }

      // Save to localStorage
      localStorage.setItem('convertedApps', JSON.stringify(convertedApps));

      // Reset form
      if (!editingApp) {
        setForm({
          websiteUrl: '',
          appName: '',
          packageName: '',
          admobAppId: '',
          admobBannerId: '',
          admobInterstitialId: '',
        });
        setFiles({
          htmlZip: null,
          appIcon: null,
          splashScreen: null,
        });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Conversion failed');
    } finally {
      setIsConverting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: keyof FileUpload) => {
    if (e.target.files && e.target.files[0]) {
      setFiles(prev => ({
        ...prev,
        [type]: e.target.files![0]
      }));
      toast.success(`${type} uploaded successfully!`);
    }
  };

  const handleEdit = (app: ConvertedApp) => {
    setEditingApp(app);
    setForm({
      websiteUrl: app.websiteUrl || '',
      appName: app.appName,
      packageName: app.packageName,
      admobAppId: '',
      admobBannerId: '',
      admobInterstitialId: '',
    });
    setConversionType(app.websiteUrl ? 'url' : 'zip');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (appId: string) => {
    if (confirm('Are you sure you want to delete this app?')) {
      setConvertedApps(prev => prev.filter(app => app.id !== appId));
      toast.success('App deleted successfully!');
    }
  };

  const handleDownload = (app: ConvertedApp) => {
    // Simulate download delay
    toast.promise(
      new Promise(resolve => setTimeout(resolve, 1500)),
      {
        loading: 'Preparing download...',
        success: 'APK downloaded successfully!',
        error: 'Download failed',
      }
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <Toaster position="top-right" />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-6">
              <Smartphone className="h-12 w-12 text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              {editingApp ? 'Edit Android App' : 'Website to APK Converter'}
            </h1>
            <p className="text-lg text-gray-600">
              {editingApp 
                ? 'Update your existing Android app'
                : 'Convert your website or HTML files into a professional Android app'}
            </p>
          </div>

          {/* Conversion Type Toggle */}
          <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
            <div className="flex justify-center space-x-4">
              <button
                onClick={() => setConversionType('url')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  conversionType === 'url'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Globe className="w-5 h-5 mr-2" />
                Website URL
              </button>
              <button
                onClick={() => setConversionType('zip')}
                className={`px-6 py-3 rounded-lg flex items-center ${
                  conversionType === 'zip'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Package className="w-5 h-5 mr-2" />
                HTML ZIP
              </button>
            </div>
          </div>

          {/* Main Form */}
          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8">
            <div className="space-y-6">
              {/* Source Input */}
              {conversionType === 'url' ? (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Website URL
                  </label>
                  <input
                    type="url"
                    name="websiteUrl"
                    value={form.websiteUrl}
                    onChange={handleInputChange}
                    placeholder="https://your-website.com"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    HTML ZIP File
                  </label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                    <div className="space-y-1 text-center">
                      <Package className="mx-auto h-12 w-12 text-gray-400" />
                      <div className="flex text-sm text-gray-600">
                        <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                          <span>Upload a ZIP file</span>
                          <input
                            type="file"
                            ref={fileInputRef}
                            accept=".zip"
                            onChange={(e) => handleFileChange(e, 'htmlZip')}
                            className="sr-only"
                          />
                        </label>
                      </div>
                      <p className="text-xs text-gray-500">
                        {files.htmlZip ? files.htmlZip.name : 'ZIP file containing your HTML website'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* App Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    App Name
                  </label>
                  <input
                    type="text"
                    name="appName"
                    value={form.appName}
                    onChange={handleInputChange}
                    placeholder="My App"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Package Name
                  </label>
                  <input
                    type="text"
                    name="packageName"
                    value={form.packageName}
                    onChange={handleInputChange}
                    placeholder="com.example.myapp"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
              </div>

              {/* App Icon & Splash Screen */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    App Icon
                  </label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                    <div className="space-y-1 text-center">
                      {files.appIcon ? (
                        <img
                          src={URL.createObjectURL(files.appIcon)}
                          alt="App Icon Preview"
                          className="mx-auto h-24 w-24 object-contain"
                        />
                      ) : (
                        <Image className="mx-auto h-12 w-12 text-gray-400" />
                      )}
                      <div className="flex text-sm text-gray-600">
                        <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                          <span>Upload an icon</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'appIcon')}
                            className="sr-only"
                          />
                        </label>
                      </div>
                      <p className="text-xs text-gray-500">
                        {files.appIcon ? files.appIcon.name : 'Recommended: 512x512px'}
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Splash Screen (Optional)
                  </label>
                  <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-lg">
                    <div className="space-y-1 text-center">
                      {files.splashScreen ? (
                        <img
                          src={URL.createObjectURL(files.splashScreen)}
                          alt="Splash Screen Preview"
                          className="mx-auto h-24 w-24 object-contain"
                        />
                      ) : (
                        <Image className="mx-auto h-12 w-12 text-gray-400" />
                      )}
                      <div className="flex text-sm text-gray-600">
                        <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                          <span>Upload splash screen</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileChange(e, 'splashScreen')}
                            className="sr-only"
                          />
                        </label>
                      </div>
                      <p className="text-xs text-gray-500">
                        {files.splashScreen ? files.splashScreen.name : 'Recommended: 1080x1920px'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* AdMob Integration Toggle */}
              <div className="border-t pt-6">
                <button
                  type="button"
                  onClick={() => setShowAdmobFields(!showAdmobFields)}
                  className="flex items-center text-blue-600 hover:text-blue-800"
                >
                  <Settings className="w-5 h-5 mr-2" />
                  {showAdmobFields ? 'Hide' : 'Configure'} AdMob Integration
                </button>
              </div>

              {/* AdMob Fields */}
              {showAdmobFields && (
                <div className="space-y-4 border-t pt-4">
                  <div className="bg-blue-50 p-4 rounded-lg flex items-start">
                    <AlertCircle className="w-5 h-5 text-blue-500 mt-1 mr-2" />
                    <p className="text-sm text-blue-700">
                      Add your AdMob credentials to monetize your app. Leave empty if you don't want to include ads.
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      AdMob App ID
                    </label>
                    <input
                      type="text"
                      name="admobAppId"
                      value={form.admobAppId}
                      onChange={handleInputChange}
                      placeholder="ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Banner Ad Unit ID
                      </label>
                      <input
                        type="text"
                        name="admobBannerId"
                        value={form.admobBannerId}
                        onChange={handleInputChange}
                        placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Interstitial Ad Unit ID
                      </label>
                      <input
                        type="text"
                        name="admobInterstitialId"
                        value={form.admobInterstitialId}
                        onChange={handleInputChange}
                        placeholder="ca-app-pub-xxxxxxxxxxxxxxxx/yyyyyyyyyy"
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isConverting}
                className={`w-full flex items-center justify-center px-6 py-3 rounded-lg text-white font-medium ${
                  isConverting
                    ? 'bg-gray-400 cursor-not-allowed'
                    : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                {isConverting ? (
                  <>
                    <Upload className="animate-spin mr-2 h-5 w-5" />
                    {editingApp ? 'Updating...' : 'Converting...'}
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-5 w-5" />
                    {editingApp ? 'Update App' : 'Convert to APK'}
                  </>
                )}
              </button>

              {editingApp && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingApp(null);
                    setForm({
                      websiteUrl: '',
                      appName: '',
                      packageName: '',
                      admobAppId: '',
                      admobBannerId: '',
                      admobInterstitialId: '',
                    });
                    setFiles({
                      htmlZip: null,
                      appIcon: null,
                      splashScreen: null,
                    });
                  }}
                  className="w-full mt-4 px-6 py-3 rounded-lg text-gray-700 font-medium bg-gray-100 hover:bg-gray-200"
                >
                  Cancel Editing
                </button>
              )}
            </div>
          </form>

          {/* Converted Apps List */}
          {convertedApps.length > 0 && (
            <div className="mt-12 bg-white rounded-xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Apps</h2>
              <div className="space-y-6">
                {convertedApps.map(app => (
                  <div key={app.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <img
                        src={app.appIcon}
                        alt={app.appName}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                      <div>
                        <h3 className="font-medium text-gray-900">{app.appName}</h3>
                        <p className="text-sm text-gray-500">{app.packageName}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleEdit(app)}
                        className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                      >
                        <Edit className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDownload(app)}
                        className="p-2 text-green-600 hover:bg-green-50 rounded-lg"
                      >
                        <Download className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleDelete(app.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                      >
                        <Trash className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Features Section */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Globe className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Multiple Sources</h3>
              <p className="text-gray-600">Convert from live URLs or upload your HTML files directly</p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Image className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Custom Branding</h3>
              <p className="text-gray-600">Add your own app icon and splash screen</p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Secure & Private</h3>
              <p className="text-gray-600">Your app data is processed securely and never stored</p>
            </div>
          </div>

          {/* Additional Information */}
          <div className="mt-12 bg-white rounded-xl shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">How It Works</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-600">
                    1
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Enter Your Details</h3>
                  <p className="mt-1 text-gray-500">Provide your website URL or upload your HTML files along with app information</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-600">
                    2
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Customize Your App</h3>
                  <p className="mt-1 text-gray-500">Add your app icon, splash screen, and configure AdMob if desired</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-600">
                    3
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">Generate & Download</h3>
                  <p className="mt-1 text-gray-500">Click convert and download your ready-to-publish Android APK</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;